Flappy Loloy - Android Studio project

1. Install Android Studio (free) and choose File > Open, then pick this folder.
2. Wait for Gradle sync to finish (needs internet the first time).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk.
5. Send that APK to people. They must allow "Install unknown apps" to install it.

The game lives in app/src/main/assets/index.html. Edit it to change the game.
